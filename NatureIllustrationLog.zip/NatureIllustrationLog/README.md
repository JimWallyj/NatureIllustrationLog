# Nature Illustration Log and Locator — First Build

This is a working first pass at the spec, built with SwiftUI + SwiftData.
It's meant as a starting point to open in Xcode and iterate on — including
with Claude Code, if you want an agent that can build and run it for you.

## Setting it up in Xcode

1. Open Xcode → **File → New → Project → App**.
2. Product name: `NatureIllustrationLog`. Interface: **SwiftUI**. Storage: **SwiftData**.
3. Set the deployment target: iPhone (16+) and iPad (10th generation or
   later) — see the device note below.
4. Delete the default `ContentView.swift` and the auto-generated `Item.swift`
   Xcode creates for you.
5. Drag the `Models`, `Services`, and `Views` folders, plus
   `NatureIllustrationLogApp.swift`, into the project (check "Copy items if
   needed" and add to your app target).
6. Open your target's **Info** tab and add this key (required to read a
   photo's date/location metadata):
   - `Privacy - Photo Library Usage Description` — e.g. "Used to read the
     date and location of photos you add to your nature log."
7. Build and run.

## Decisions made while coding, per your answers

- **Photo storage:** photos are copied into the app's own SwiftData storage
  (`@Attribute(.externalStorage)`) at Add time, so they persist even if the
  original is later deleted from Photos.
- **Location:** read automatically from the photo's metadata via its
  Photos asset (creation date + GPS), then reverse-geocoded into a short
  place name for display. If a photo has no location data, the File Screen
  says so instead of showing a map.
- **iPad target:** the spec's "iPad 4th generation" doesn't run iOS 26.3, so
  the setup steps above target iPad 10th generation or later instead.

## A few small gaps I filled in with reasonable defaults

- **Save button on the File Screen:** the spec flagged this as an open
  question. I used SwiftData's autosave instead of an explicit Save button —
  edits to Field Notes and Illustration Project Notes save as you type. Say
  the word if you'd rather have an explicit Save button there.
- **Multiple photos per file:** the spec describes one photo per subject
  file, so that's what's built. If you actually want multiple photos per
  entry, that's a data model change worth doing now rather than later.
- **Home screen default background:** before the user sets one via Edit
  Home, it shows a simple green/brown gradient rather than a placeholder
  photo (no image assets are bundled).
- **Swipe-to-delete:** built with no confirmation step, per the spec's
  wording ("ability to swipe... to delete"). Add a confirmation dialog
  easily if you'd rather guard against accidental deletes.

## Not yet built (the spec left these open)

- Section 5 (Data Model) beyond what's inferable from the screens
- Section 6 (Feature Specs) — no features beyond the screens were named
- Section 8 (Testing) — no unit tests included yet
