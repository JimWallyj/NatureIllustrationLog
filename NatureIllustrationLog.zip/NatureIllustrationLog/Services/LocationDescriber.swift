import CoreLocation

/// Turns a coordinate into a short, human-readable place name (e.g.
/// "Sedona, AZ") for display under the map on the File Screen. This is a
/// one-off reverse geocode of a fixed coordinate and does not require the
/// user's own location permission.
func reverseGeocode(latitude: Double, longitude: Double, completion: @escaping (String?) -> Void) {
    let geocoder = CLGeocoder()
    let location = CLLocation(latitude: latitude, longitude: longitude)
    geocoder.reverseGeocodeLocation(location) { placemarks, _ in
        guard let placemark = placemarks?.first else {
            completion(nil)
            return
        }
        let parts = [placemark.locality, placemark.administrativeArea].compactMap { $0 }
        completion(parts.isEmpty ? nil : parts.joined(separator: ", "))
    }
}
